package com.payco.contents.bot.configure;

import com.payco.contents.bot.download.DownloadWriter;
import com.payco.contents.bot.download.DownloadTemplate;
import com.payco.contents.bot.download.test.TestDao;
import com.payco.contents.bot.download.test.model.DownloadItem;
import com.payco.contents.bot.download.test.model.DownloadReq;
import com.payco.contents.bot.download.test.service.DownloadInitializerImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.PageRequest;

@Configuration
public class testConfigure {
	@Bean
	public DownloadTemplate<DownloadItem, DownloadReq> testDownloadTemplate(TestDao dao) {

		return new DownloadTemplate<>(dao, new DownloadInitializerImpl(), new SimpleDownloadWriter(), PageRequest.of(0, 3), 5);
	}

	static class SimpleDownloadWriter implements DownloadWriter<DownloadItem> {
	}

}
