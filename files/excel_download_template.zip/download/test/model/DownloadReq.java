package com.payco.contents.bot.download.test.model;


import com.payco.contents.bot.download.model.DownloadRequest;

public class DownloadReq implements DownloadRequest {

}
