package com.payco.contents.bot.download.test.model;

import java.util.Arrays;
import java.util.List;

import com.payco.contents.bot.download.model.DownloadItemLine;
import lombok.Data;

@Data
public class DownloadItem implements DownloadItemLine {

    private String a;
    private String b;

    @Override
    public List<String> toLineItems() {
        return Arrays.asList(a, b);
    }
}
