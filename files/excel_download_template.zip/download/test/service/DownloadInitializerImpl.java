package com.payco.contents.bot.download.test.service;

import com.payco.contents.bot.download.DownloadInitializer;
import com.payco.contents.bot.download.DownloadTemplate;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

public class DownloadInitializerImpl implements DownloadInitializer {

    @Override
    public SXSSFWorkbook initialize(int flushSize) {
        SXSSFWorkbook workbook = new SXSSFWorkbook(flushSize);
        Sheet sheet = workbook.createSheet(DownloadTemplate.DEFAULT_SHEET_NAME);
        Row titleRow = sheet.createRow(0);
        titleRow.createCell(0).setCellValue("a");
        titleRow.createCell(1).setCellValue("b");

        return workbook;
    }
}
