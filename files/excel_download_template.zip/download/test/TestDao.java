package com.payco.contents.bot.download.test;

import com.payco.contents.bot.download.DownloadItemReader;
import com.payco.contents.bot.download.test.model.DownloadItem;
import com.payco.contents.bot.download.test.model.DownloadReq;
import io.github.benas.randombeans.api.EnhancedRandom;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

@Slf4j
@RequiredArgsConstructor
@Repository
public class TestDao implements DownloadItemReader<DownloadItem, DownloadReq> {



    private List<DownloadItem> items = EnhancedRandom.randomListOf(100, DownloadItem.class);

    @Override
    public Page<DownloadItem> read(DownloadReq request, Pageable pageable) {

        log.info("read called page: {}", pageable.getPageNumber());
        int size = Integer.min(items.size(), (int) (pageable.getOffset() + pageable.getPageSize()));

        List<DownloadItem> result = items.subList((int) pageable.getOffset(), size);
        return new PageImpl<>(result, pageable, items.size());
    }
}
