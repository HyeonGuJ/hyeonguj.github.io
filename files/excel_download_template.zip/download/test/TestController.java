package com.payco.contents.bot.download.test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletResponse;

import com.payco.contents.bot.download.DownloadTemplate;
import com.payco.contents.bot.download.test.model.DownloadItem;
import com.payco.contents.bot.download.test.model.DownloadReq;
import lombok.RequiredArgsConstructor;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor
@RestController
public class TestController {

    private final DownloadTemplate<DownloadItem, DownloadReq> testDownloadTemplate;

    @ResponseBody
    @GetMapping("/test/download")
    public void download(DownloadReq req, HttpServletResponse response) throws IOException {

        SXSSFWorkbook workbook = testDownloadTemplate.createDownloadFile(req);
        response.setHeader("Set-Cookie", "fileDownload=true; path=/");
        response.setHeader("Content-Disposition", String.format("attachment; filename=\"test.xlsx\""));
        workbook.write(response.getOutputStream());
    }
}
