package com.payco.contents.bot.download;

import com.payco.contents.bot.download.model.DownloadItemLine;
import com.payco.contents.bot.download.model.DownloadRequest;
import lombok.RequiredArgsConstructor;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

@RequiredArgsConstructor
public class DownloadTemplate<T extends DownloadItemLine, R extends DownloadRequest> {

    public static final String DEFAULT_SHEET_NAME = "first_sheet";

    private final DownloadItemReader<T, R> reader;
    private final DownloadInitializer initializer;
    private final DownloadWriter<T> writer;
    private final Pageable defaultPageable;
    private final int flushSize;

    public SXSSFWorkbook createDownloadFile(R request) {
        Page<T> result;
        SXSSFWorkbook workbook = initializer.initialize(flushSize);
        Pageable pageable = PageRequest.of(0, defaultPageable.getPageSize());

        try {
            do {
                result = reader.read(request, pageable);
                writer.write(workbook, result.getContent());
                pageable = pageable.next();
            } while (result.hasNext());
        } catch (Exception e) {
            workbook.dispose();
            throw e;
        }

        return workbook;
    }
}
