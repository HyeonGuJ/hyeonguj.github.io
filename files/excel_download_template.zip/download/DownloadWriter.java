package com.payco.contents.bot.download;

import java.util.List;
import java.util.Objects;

import com.payco.contents.bot.download.model.DownloadItemLine;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

public interface DownloadWriter<T extends DownloadItemLine> {

    default void write(SXSSFWorkbook workbook, List<T> lines) {
        Sheet sheet = workbook.getSheet(DownloadTemplate.DEFAULT_SHEET_NAME);
        int index = sheet.getLastRowNum() + 1;

        for (int i = 0; i < lines.size(); i++) {
            Row row = sheet.getRow(index + i);
            if (Objects.isNull(row)) {
                row = sheet.createRow(index + i);
            }

            List<String> columnTexts = lines.get(i).toLineItems();

            for (int j = 0; j < columnTexts.size(); j++) {
                Cell cell = row.getCell(j);
                if (Objects.isNull(cell)) {
                    cell = row.createCell(j);
                }
                String value = columnTexts.get(j);
                if (StringUtils.isNotBlank(value)) {
                    cell.setCellValue(value);
                }
            }
        }
    }
}
