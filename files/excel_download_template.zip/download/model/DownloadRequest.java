package com.payco.contents.bot.download.model;

public interface DownloadRequest {

}
