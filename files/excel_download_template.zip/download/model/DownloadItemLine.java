package com.payco.contents.bot.download.model;

import java.util.List;

public interface DownloadItemLine {

    List<String> toLineItems();
}
