package com.payco.contents.bot.download;

import com.payco.contents.bot.download.model.DownloadItemLine;
import com.payco.contents.bot.download.model.DownloadRequest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface DownloadItemReader<T extends DownloadItemLine, R extends DownloadRequest> {

    Page<T> read(R request, Pageable pageable);
}
