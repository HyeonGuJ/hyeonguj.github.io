package com.payco.contents.bot.download;

import org.apache.poi.xssf.streaming.SXSSFWorkbook;

public interface DownloadInitializer {

    SXSSFWorkbook initialize(int flushSize);
}
